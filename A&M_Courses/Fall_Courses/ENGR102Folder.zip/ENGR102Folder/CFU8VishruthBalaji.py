#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  7 08:01:40 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: CFU Week 8
# Date: 10/7/2020

import math
import random

#Find a number between 1 and 5 for radius and 0 to 360 for theta 
radius_Length = random.randint(1,6)
theta_Degrees = random.randint(0,361)
print(radius_Length)
print(theta_Degrees)
radians_Length = theta_Degrees * (math.pi/180.0)

#Calculate for the x and y lenghs
x_Length = radius_Length * math.cos(radians_Length)
y_Length = radius_Length * math.sin(radians_Length)

#Output the x_Length and y_Length into Catesian Coordinates
print('(',x_Length,',',y_Length,')')
print('(%.2f,%.2f)' % (x_Length,y_Length))


#Function: def calculatex_length(radius_Length,theta_Degrees)

#Function: def calculatey_length(radius_Length,theta_Degrees)