#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 31 08:19:40 2020

@author: vishruth
"""
from math import*

#ICAL1
myVar = 123.456789
myString = 'The value of myVar is %6.2f' % myVar
print('\n',myString,'\n')

#ICAL2
myVar = 123.456789
myVar1 = 7.8901
myVar2 = -0.0235
print('myVar = %6.2f  myVar1 = %4.1f  myVar2 = %7.3f' % (myVar, myVar1, myVar2))

A = 123.45678
B = 0.000045678
C = 10105
myString = 'Howdy'
print('\nHere are all four values %6.2f    %.3e     %d    %s' % (A, B, C, myString))


#ICAL3
Theta = "theta"
Func1 = "cos()"
Func2 = "sin()"

theta1 = 0 # radians
theta2 = pi/6 # radians
theta3 = pi/4 # radians
theta4 = pi/3 # radians
theta5 = pi/2 # radians

# a good first guess is to match the width of the labels with the width of the data fields
print("%6s %6s %6s" % (Theta, Func1, Func2 ))
print("%6s %6s %6s" % ("(rad)", "----", "----"))

print("%6.2f %6.2f %6.2f" % (theta1, cos(theta1), sin(theta1)))
print("%6.2f %6.2f %6.2f" % (theta2, cos(theta2), sin(theta2)))
print("%6.2f %6.2f %6.2f" % (theta3, cos(theta3), sin(theta3)))
print("%6.2f %6.2f %6.2f" % (theta4, cos(theta4), sin(theta4)))
print("%6.2f %6.2f %6.2f" % (theta5, cos(theta5), sin(theta5)))


#ICAL4
First1 = "Emma"
Last1 = "Smith"
Phone1 = "(555)234-5678"
First2 = "Noah"
Last2 = "Johnson"
Phone2 = "(555)234-2233"
First3 = "Olivia"
Last3 = "Williams"
Phone3 = "(555)234-9826"

print()
print()
print("%8s %10s %14s" % (First1, Last1, Phone1))
print("%8s %10s %14s" % (First2, Last2, Phone2))
print("%8s %10s %14s" % (First3, Last3, Phone3))
