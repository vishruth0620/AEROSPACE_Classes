#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 19 21:25:11 2020

@author: vishruth
"""
# Name: Vishruth Balaji
# Assignment Lab 1B: Activity 2
# Section: ENGR 102-451


print("Howdy, World!")
print("I'm a 6-footer and love to play basketball.")
