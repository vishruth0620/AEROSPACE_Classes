#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 19 13:36:06 2020

@author: vishruth
"""

print("Gig 'em!, Whoop!");