#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 19 08:28:41 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: ICAL 6-1
# Date: 10/19/2020

### Part A ###
f = open("demofile.txt","r")
print(f.read())
f.close()
### Part B ###
f = open("demofile.txt","r")
print(f.read(5))
f.close()
### Part C ###
f = open("demofile.txt","r")
print('\n',f.readline())
f.close()
### Part D ###
f = open("demofile.txt","r")
print(f.readline())
print(f.readline())
f.close()
### Part E ###
f = open("demofile.txt","r")
for x in f:
   print(x)
f.close()