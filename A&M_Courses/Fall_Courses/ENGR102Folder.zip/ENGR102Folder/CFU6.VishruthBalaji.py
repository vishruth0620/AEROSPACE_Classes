#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 07:52:53 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Section: 102-451
# Assignment: CFU Week 6
# Date: 9/23/2020

#Test Cases
#1. 1/2 + 2/3 
#2. 6/13 + 5/6
#3. 3/20 + 4/3

import fractions

#Inputting numbers of the numerators of the first and second fractions
fraction1_Numerator = int(input('Enter the numerator for the first fraction: '))
fraction2_Numerator = int(input('Enter the numerator for the first fraction: '))
#Inputting numbers of the denominators of the first and second fractions
fraction1_Denominator = int(input('Enter the denominator for the first fraction: '))
fraction2_Denominator = int(input('Enter the denominator for the first fraction: '))

#Calculating the sum of the two fractions using a sum_Fractions variable
sum_Fractions = (fraction1_Numerator / fraction1_Denominator) + (fraction2_Numerator / fraction2_Denominator)

#Output the sum of the two fractions to the console
fraction_Convertor = fractions.Fraction(sum_Fractions)
print(fraction_Convertor)
