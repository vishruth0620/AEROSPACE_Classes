#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  2 08:18:52 2020

@author: vishruth
"""
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: Week 3 CFU Quiz
# Date: 9/2/2020

from math import *

#Inputting names of three test scores
name1 = str(input('User 1, please the first name: '))
name2 = str(input('User 2, please the second name: '))
name3 = str(input('User 3, please the third name: '))

num_Exams = 3
#Inputting test score values three test scores
test_score_1 = int(input("Enter the first test score: "))
test_score_2 = int(input("Enter the second test score: "))
test_score_3 = int(input("Enter the third test score: "))

#Finding the test average of all  three exams
test_AVG = (test_score_1 + test_score_2 + test_score_3) / 3


sum_Squared_Differences = (((test_score_1 - test_AVG) ** 2) + ((test_score_2 - test_AVG) ** 2) + ((test_score_3 - test_AVG) ** 2))

standard_Deviation = ((sum_Squared_Differences) / (num_Exams-1)) ** (1/2)

print('')