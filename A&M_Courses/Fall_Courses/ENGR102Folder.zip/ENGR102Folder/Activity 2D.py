#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 19 20:46:16 2020

@author: vishruth
"""

from math import *;
print(cos(0));
print(sin(0));
print(1/0);
print();
