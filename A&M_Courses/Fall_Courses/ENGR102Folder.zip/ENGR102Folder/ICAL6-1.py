#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 21 08:03:08 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: ICAL 6-1
# Date: 9/21/2020

#Set a variable to set the range between 1500 and 2700 (included)
num_Range = range(1500, 2700 + 1)

#Set a for loop to use numbers between the variable set in the for loop
for num in (num_Range):
    #Find if the values between 1500 and 2700 is divisible by 7 and multiple of 5
    if((num % 7 == 0) and (num % 5 == 0)):
        #Printing the number onto the screen if the if statement is true
        print('{:d}'.format(num))
        
        
        
    