#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 18 19:51:34 2020

@author: vishruth
"""
# By submitting this assignment I agree to the following
# “Aggies do not, lie, cheat, or steal, or tolerate those who do”
# “I have not given or received any unauthorized aid on this assignment”
#
#Name			Liliana Salgado
#Section		501
#Assignment		Lab8_Act2
#Date			10/7/2020

v=[0.0009977,0.0009996,0.0010057,0.0010149,0.0010267,0.0010410,0.0010576,0.0010769,0.0010988,0.0011240,0.0011531,0.0011868,0.0012268,0.0012755]

u=[0.04,83.61,166.92,250.29,333.82,417.65,501.91,586.8,672.55,759.47,847.92,938.39,1031.6,1128.5]

h=[5.03,88.61,171.95,255.36,338.96,422.85,507.19,592.18,678.04,765.09,853.68,944.32,1037.7,1134.9]
