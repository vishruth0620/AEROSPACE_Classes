#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 08:10:09 2020

@author: vishruth
"""

# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: CFU Week 12
# Date: 10/28/2020

import webbrowser as wb

#Inputting two urls on the console
url_1 = input('Enter the first url: ')
url_2 = input('Enter the second url: ')

#Opening the first url to a default window
wb.open_new(url_1)

#Open the tab for second url to the same window in a new tab
wb.open_new_tab(url_2)