#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct  5 08:24:30 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: ICAl-8
# Date: 10/5/2020

### Purpose ###

# Consider a person who rolls 5 dice. If all dice are the same value, that 
# person wins and stops rolling. If the dice are not all the same value, the 
# person picks up all 5 dice and re-rolls until they get a roll of all the same 
# value.
#
# This program simulates how many rolls are needed until they win. 

def main():
    
    # Enter in a limited amount of tries to run, num
    
    # Initialize a counter to get the number of times the dice is rolled to 0
    
    # In a for loop that goes up to num times
        # run a simulation to find the number
        # add it to number of times unitl you win

    # Get the average number of dice roll using variable average
    # Print average to the screen
    
    
# def diceSolution(num_Count,find_Number):
    
    # Run a simulation of the roling the 5 dice
    # Input to the user how many dice you would want to roll
    # Input to user how many sides you want on each dice
    # Create of list to store values of the 5 dice
    # Ask the user to roll the number of dice
    
    # In a for loop up to n times
        # Add values to the list
        # Check if the values on each element of the list has the same value
            #Set the variable find_Num 
            # If it has then add to the num
       
        # Else
            # Ask the user to roll the number of dice
         
        #return find_Number
        #return num_Count
