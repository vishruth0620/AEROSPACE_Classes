#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 30 08:02:21 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: CFU Week 7
# Date: 9/30/2020

#Create a new list called listofHeights
#input a feet and inches variable
listofHeights = []
feet = int(input('Enter the number of feet: '))
inches = int(input('Enter the number of inches: '))  

#Caluclate for total inches by doing feet * 12 + inches 
#Then append it to the listofHeights list
while (feet != 0 or inches != 0):
    inches += (feet * 12)
    listofHeights.append(inches)
    feet = int(input('Enter the number of feet: '))
    inches = int(input('Enter the number of inches: '))  

#Convert each value in the listofHeights to centimeters
for height in range(len(listofHeights)):
    listofHeights[height] = round(listofHeights[height] * 2.54, 2)

#Output the new listofHeights to the console
print(listofHeights)
    
    