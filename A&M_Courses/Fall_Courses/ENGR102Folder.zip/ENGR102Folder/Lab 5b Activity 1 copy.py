#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 14 23:00:10 2020

@author: vishruth
"""

# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji, Hunter Spier, Liliana Salgado, Michael Camacho
# Course Header: Eng 102-451
# Assignment: Lab 5b Activity 1a
# Date: 9/14/2020
counter = 0;
num = int(input('Enter a positive integer to compute the Collatz sequence: '))
print('Here is the Collatz sequence starting at {}: '.format(num))
print('%d'% (num), end = '')

while num != 1 :
    if (num % 2 == 0) :
        num /= 2
        print(', %d'% (num), end = '')
    
    elif (num % 2 != 0) :
        num = (3 * num) + 1
        print(', %d'% (num), end = '')
    
    counter += 1

 
print('\nIt took {:d} iterations to reach 1.'.format(counter))  