#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 28 08:11:21 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: ICAL 7-2
# Date: 9/28/2020

#### Part A ####
thislist = ['apple','banana','cherry','orange','kiwi','melon','mango']
print(thislist[:4])

#### Part B ####
thislist = ['apple','banana','cherry','orange','kiwi','melon','mango']
print(thislist[2:])

#### Part C ####
thislist = ['apple','banana','cherry','orange','kiwi','melon','mango']
print(thislist[-4:-1])

#### Part D ####
thislist = ['apple','banana','cherry']
thislist[1] = 'blackcurrant'
print(thislist)



