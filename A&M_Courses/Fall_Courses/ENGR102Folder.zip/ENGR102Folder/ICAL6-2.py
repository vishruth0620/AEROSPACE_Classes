#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 21 08:36:06 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: ICAL 6-1
# Date: 9/21/2020

#Setting default variables when finding Fareheit and Celcius ad flating-point variables
find_Celcius = 0.0
find_Fahrenheit = 0.0

#Input a variable for temperature in Celcius as floating-point variables
temp_Celcius = float(input('Enter the temperature in Celcius: '))
#Input a variable for temperature in Fahrenheit
temp_Fahrenheit = float(input('Enter the temperature in Fahrenheit: '))

#Calculate the temperature from Celcius to Fahrenheit
find_Fahrenheit = (1.8 * temp_Celcius) + 32.0
#Calculate the temperature from Fahrenheit to Celcius
find_Celcius = (temp_Fahrenheit - 32.0) / 1.8

#Printing the temperature in Fahrenheit rounding to 1 decimal
print('\nThe temperature in Fahrenheit is {:.1f} degrees Fahrenheit.'.format(find_Fahrenheit))
#Printing the temperature in Celcius rounding to 1 decimal
print('\nThe temperature in Celcius is {:.1f} degrees Celcius.'.format(find_Celcius))


