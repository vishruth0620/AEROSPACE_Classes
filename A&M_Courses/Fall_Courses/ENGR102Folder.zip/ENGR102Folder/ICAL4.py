#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 08:03:31 2020

@author: vishruth
"""

#ICAL 4-1
a = 33
b = 200

if (b > a) :
    print('b is greater than a')
    

#ICAL 4-2
a = 33
b = 33

if (b>a) :
    print('b is greater than a')

elif (a == b) :
    print('a and b are equal')


#ICAL 4-3
a = 200
b = 33

if (b > a) :
    print('b is greater than a')
    
elif(a == b) :
    print('a and b are equal')
    
else:
    print('a is greater than b')
    

#ICAL 4-4
a = 200
b = 33

if (b > a) :
    print('b is greater than a')
else :
     print('b is not greater than a')
     
#ICAL 4-5
a = 200
b = 33
if(b > a) :
     print('b is greater than a')
else :
    print('b is not greater than a')