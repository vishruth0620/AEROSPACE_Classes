#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 21 08:11:32 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Section: 102-451
# Assignment: CFUL Week 9
# Date: 10/21/2020


current_year = 2033 #Set the current_year to when your 64
birth_year = int(input('Please enter your date of birth XXXX: '))#Set the birth_year
while birth_year < current_year: #Conditional to birth_year <= current_year
    ageto64 = 64 - (current_year - birth_year)#Compute calculation to variable ageto64
    print("You have", ageto64, "years until you reach 64.")#Output the ageto64
    birth_year += 1
print('I have ------- years before I turn 64')