#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 28 08:22:48 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: ICAL 7-3
# Date: 9/28/2020

#### Part A ####
thislist = ['apple','banana','cherry']
if 'apple' in thislist :
    print('Yes, \'apple\' is in the fruits list.')
    
#### Part B ####
thislist = ['apple','banana','cherry']
print(len(thislist))

#### Part C ####
thislist = ['apple','banana','cherry']
thislist.append('orange')
print(thislist)

#### Part D ####
list1 = ['a', 'b', 'c']
list2 = [1,2,3]


list3 = list1 + list2
print(list3)