#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 19 13:37:34 2020

@author: vishruth
"""
import numpy;
import matplotlib;