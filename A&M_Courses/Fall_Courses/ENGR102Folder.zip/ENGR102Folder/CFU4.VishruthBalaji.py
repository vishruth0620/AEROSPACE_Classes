#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  9 08:02:09 2020

@author: vishruth
"""

# Name: Vishruth Balaji
# Assignment Week 4 CFU Quiz
# Section: ENGR 102-451
# Date: September 9, 2020

#Inputting variables to finding grade
grade = 0.0
extra_Credit = 0.0
user_homework_Score = float(input('The student\'s homework score: '))
exam_Score = float(input('The student\'s homework score: '))
did_Project = bool(input('Did you do the Project ? True or False? '))

exam_Score *= 0.60
user_homework_Score *= 0.40

#Asking if the student did the project
if (did_Project) : 
    extra_Credit = 5.0

grade = float(exam_Score + user_homework_Score + extra_Credit)

#Printing out the Student's Grade
if (grade >= 90.0) :
     print('A')
     
elif (80.0 <= grade < 90.0) :
     print('B')
     
elif (70.0 <= grade < 80.0) :
     print('C')
     
elif (60.0 <= grade < 70.0) : 
     print('D') 

else : 
     print('F')




