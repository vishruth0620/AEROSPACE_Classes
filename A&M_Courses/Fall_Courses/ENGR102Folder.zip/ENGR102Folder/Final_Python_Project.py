#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 16:49:18 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji, Hunter Spier, Liliana Salgado, Michael Camacho
# Course Header: Eng 102-451
# Assignment: Final Project
# Date: 11/14/2020

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

def createbinlist(min, max):# Function for Instruction 2 and 6 to create the bins list for the histogram

    '''
    param min : float
    param max : float
    return bins : list
    '''

    bin_interval = (max - min) / 15.0 #Create an interval
    bins = [] #Create a new list
    i = min
    #Add energy intervals for the bins
    while (i < max+1):
        bins.append(i)
        i += bin_interval
    
    return bins

def findminmax(list_Ener): #Function for Instruction 2 and 6 to find min and max energy consumption
    
    '''
    param list_Ener : list
    return min and max : float
    '''
    
    max = 0.0
    min = 9999999999.0
    
    for i in range(len(list_Ener)): #Find the maxiumum energy
        if(list_Ener[i] > max):
            max = list_Ener[i]
        
        if(list_Ener[i] < min): #Find the minimum energy
            min = list_Ener[i]
        
    return min,max
        
def plotEnergyValues(bin_Years,energy_Vals,country,color): # Function for Instruction 2 to plot the histogram for each country
     
    '''
    param bin_Years : list
    param energy_Vals : list
    param country : string
    param color : string
    '''
    plt.figure()
    y_Vals = np.arange(0,51,5)
    plt.yticks(y_Vals)
    plt.hist(energy_Vals,bin_Years,rwidth = 1.0,facecolor = color,alpha = 1.0)
    plt.title('Energy Consumers for {:s}'.format(country))
    plt.xlabel('Energy Consumption')
    plt.ylabel('Frequency')
    plt.savefig(pp, format='pdf')
    plt.show()

def converttofloat(consumer): # Function for Instruction 2 to change each energy value from a string to a float
     
    '''
    param consumer : list
    return consumer : list with floats
    '''
    
    for row in range(1,len(consumer)):
        for col in range(1,len(consumer[row])):
            value = float(consumer[row][col])
            consumer[row][col] = value
    
    return consumer


def arrangeEnergyType(list_energytype): # Function for Instruction 3
    
    '''
    param list_energytype : list
    return list_countries : list 
    '''
    
    list_countries=[] ##Create a new list for countries
    row=0
    
    while (row < len(list_energytype)):
        countryindex = -1
        #find the country index in the list of countries
        for ci in (range(len(list_countries))):
            if (list_energytype[row][0] == list_countries[ci][0]):
                countryindex = ci
                break
            
        # If the country is not there, add a new country to the list
        if (countryindex < 0):
            list_values=['', [], [], []]
            list_values[0] = list_energytype[row][0]
            list_countries.append(list_values)
            countryindex = len(list_countries)-1
           
        # Set the year, electricity value, natural gas value
        list_countries[countryindex][1].append(int(list_energytype[row][3]))
        electricity = float(list_energytype[row][1])
        list_countries[countryindex][2].append(electricity)
        row += 1
        naturalgas = float(list_energytype[row][1])
        list_countries[countryindex][3].append(naturalgas)
        
        #Iterate to next country, year
        row += 1
        
    return list_countries

def plotEnergyBar(x_Vals,y_E,y_NG,country): # Function for Instruction 4 to plot a comparison bar graph for each country
    
    '''
    param x_Vals : list
    param y_E : list 
    param y_NG : list 
    param country : string 
    '''
    
    plt.figure()
    width1 = -0.40
    width2 = 0.40
    fig,ax = plt.subplots()
    plt.title('Electricity and Natural Gas for {:s}'.format(country))
    plt.xlabel('Years')
    x_ticks = np.linspace(1990,2015,6) #Create a x_Range of years from 1990 - 2015
    plt.xticks(x_ticks)
    
    ax.bar(x_Vals,y_E, width = width1,align = 'edge',facecolor = 'g',alpha = 1,label = 'Electricity') #Plot the Electricity Bar Graph
    
    ax.bar(x_Vals, y_NG,width = width2,align = 'edge',facecolor = 'r',alpha = 1,label = 'Natural Gas') #Plot the Natural Gas Bar Graph
    plt.ylabel('Electricity and Natural Gas')
    ax.legend()
    plt.savefig(pp, format='pdf')
    plt.show()


def consumerstoUsage(consumer, l_pc, h_pc): #Function for Instruction 5 to get the Industrial Usage list or Residential Usage
    
    '''
    param consumer : list
    return Ind : list  
    '''
    
    Ind = [] #Create new list
    Ind.append(consumer[0])

    for row in range(1,len(consumer)): #Iterate each line
        Ind.append(consumer[row]) 
        for col in range(1,len(consumer[row])): #Iterate each value in the line
            value = float(consumer[row][col])
            
            if (1990 <= int(consumer[0][col-1]) <= 2000): #Check each value is between a certain time period and then multiply the value by 15  or 85%
                Ind[row][col] = value * l_pc
            
            else:
                Ind[row][col] = value * h_pc #multiply the value by 35% or 65%
    
    return Ind

def plotIndustrialUsage(bin_Years,ind_usage1,ind_usage2,country): #Function for Instruction 6
    
    '''
    param binYears : list
    param ind_usage1 : list  
    param ind_usage2 : list
    param country : string
    '''
    
    plt.figure()
    fig,ax = plt.subplots()
    
    y_Vals = np.arange(0,51,5)
    plt.yticks(y_Vals)
    
    plt.hist(ind_usage1,bin_Years,rwidth = 1.0,facecolor = 'g',alpha = 1.0,label = '1990 - 2000') #Plt the histogram from 1990 - 2000
    
    plt.hist(ind_usage2,bin_Years,rwidth = 1.0,facecolor = 'r',alpha = 1.0,label = '2001 - 2016') #Plt the histogram from 2001 - 2016
    
    plt.title('Industrial Usage for {:s}'.format(country))
    plt.xlabel('Industrial Usage')
    plt.ylabel('Frequency')
    ax.legend()
    plt.savefig(pp, format='pdf')
    plt.show()

def Continent(s,e):
    NAME = []
    for i in range(s,e+1):
        NAME.append(Residential[i])
    return NAME

def addContinent(continent, s, e):
    for i in range(s,e+1):
        continent.append(Residential[i])
    return continent

def processContinent(continents, continentname): #Function for Instruction 8
    
    '''
    param continents : list
    param continentname : string
    '''
    
    list_countries = []
    min_Continent = 99999999.0
    max_Continent = 0.0
    
    for row in range(0,len(continents)):
        list_Energies=[]
        for col in range(1,len(continents[row])):
             list_Energies.append(continents[row][col])
        
        #print(list_Energies)
        minimum,maximum = findminmax(list_Energies)
        if (minimum < min_Continent):
            min_Continent = minimum
            
        if (maximum > max_Continent):
            max_Continent = maximum
    
        list_countries.append(list_Energies)
        
    bin_Years = createbinlist(min_Continent, max_Continent)
    plotResidentialUsage(bin_Years,list_countries,continentname)
        
    

def plotResidentialUsage(bin_Years,res_usage,continentname): #Function for Instruction 9
    
    '''
    param binYears : list
    param res_usage : list  
    param continentname : string
    '''
    
    plt.figure()
    fig,ax = plt.subplots()
    
    y_Vals = np.arange(0,51,5)
    plt.yticks(y_Vals)
    
    plt.hist(res_usage,bin_Years,rwidth = 1.5,facecolor = 'b',alpha = 1.0,label = '1990 - 2016') #Plt the histogram from 1990 - 2000
      
    plt.title('Residential Usage for {:s}'.format(continentname))
    plt.xlabel('Residential Usage')
    plt.ylabel('Frequency')
    ax.legend()
    plt.savefig(pp, format='pdf')
    plt.show()



''' Main Program '''

# Instruction 1
file1 = open('EnergyConsumers.txt','r')
consumers = []
for line in file1:
    list_Values = line.split('\t')
    consumers.append(list_Values)

file1.close()

#Instruction 2
pp = PdfPages('EnergyConsumption.pdf')

consumers = converttofloat(consumers)
list_Colors = ['b','g','r','y','violet','turquoise']
counter = 0

for row in range(1,len(consumers)):
    list_Energies=[]
    for col in range(1,len(consumers[row])):
         list_Energies.append(consumers[row][col])
         
    minimum,maximum = findminmax(list_Energies)
    bin_Years = createbinlist(minimum, maximum)
    plotEnergyValues(bin_Years,list_Energies,consumers[row][0],list_Colors[counter % len(list_Colors)])
    counter += 1

# Instruction 3
file2 = open('EnergyRawDataFinal.txt','r')
file2.readline()
Energytype = []
for line in file2:
    list_Values = line.split(',')
    Energytype.append(list_Values)

list_energybycountry = arrangeEnergyType(Energytype)

file2.close()


#Instruction 4

for row in range(len(list_energybycountry)):
    x_Values = list_energybycountry[row][1]
    y_electricity= list_energybycountry[row][2]
    y_naturalgas= list_energybycountry[row][3]
    plotEnergyBar(x_Values,y_electricity,y_naturalgas,list_energybycountry[row][0])

#Instruction 5
Ind = consumerstoUsage(consumers, 0.15, 0.35)

#Instruction 6
for row in range(1,len(Ind)):
    list_Energies=[]
    for col in range(1,len(Ind[row])):
         list_Energies.append(Ind[row][col])
    
    
    minimum,maximum = findminmax(list_Energies)
    bin_Years = createbinlist(minimum, maximum)

    
    y_Ind1 = list_Energies[0:12]
    y_Ind2 = list_Energies[12:]
    plotIndustrialUsage(bin_Years,y_Ind1, y_Ind2,consumers[row][0])
    
 
#Instruction 7
plt.figure()
y_Vals = np.arange(800,4000,320)
plt.xticks(y_Vals)
minimum,maximum = findminmax(consumers[27][1:])
bin_Years = createbinlist(minimum, maximum)
plt.xlabel('Energy Consumption')
plt.ylabel('Times of repeated Energy Consumption')
plt.title('Chinese Energy use Histogram')
plt.hist(consumers[27][1:],bin_Years,rwidth = 1.0,facecolor = 'b',alpha = 1.0)
plt.savefig(pp, format='pdf')
plt.show()


#Instruction 8
Residential = consumerstoUsage(consumers, 0.85, 0.65)

Europe = Continent(1,14)
NorthAmerica = Continent(19,20)
addContinent(NorthAmerica, 25, 25)
SouthAmerica = Continent(21,24)
addContinent(SouthAmerica, 26, 26)
Asia = Continent(15,18)
addContinent(Asia,27,34)
Africa = Continent(37,40)
MiddleEast = Continent(41,44)
Australia = Continent(35,36)

#Instruction 9
processContinent(Europe,'Europe')
processContinent(NorthAmerica,'North America')
processContinent(SouthAmerica,'South America')
processContinent(Asia,'Asia')
processContinent(Africa,'Africa')
processContinent(MiddleEast,'Middle East')
processContinent(Australia, 'Australia')
pp.close()

#Instruction 10
file2 = open('CarbonEmissions.txt','r')
CarbonEmissions = []
for line in file2:
    list_Values = line.split('\t')
    CarbonEmissions.append(list_Values)

file2.close()


#Instruction 12
print('\nChina had the highest energy usage and it\'s located in the continent Asia.')    
