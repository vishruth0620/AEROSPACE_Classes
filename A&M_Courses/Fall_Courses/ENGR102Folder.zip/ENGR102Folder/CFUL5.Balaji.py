#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 16 08:06:48 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Section: 102-451
# Assignment: CFUL Week 5
# Date: 9/16/2020

repeat_Input = 1
while (repeat_Input > 0) :
    num_Factorial = int(input('Enter an integer value to solve the factorial: ')) #Inputting num from the user
    repeat_Input = num_Factorial
    #To check if number of factorial is positive
    if (num_Factorial > 0) :
        #The factorial number has to be positive to print a factorial
        factorial = 1
        while (num_Factorial > 0):
            factorial *= num_Factorial #Multiply factorial by num every time in the while
            num_Factorial -= 1 #Subtract the number by 1 to increase the factorial
        print('The factorial is %d.' % (factorial)) #Printing out the factorial answer
                