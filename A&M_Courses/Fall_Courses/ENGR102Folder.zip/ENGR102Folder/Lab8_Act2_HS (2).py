#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 18 19:52:19 2020

@author: vishruth
"""
# 	     By submitting this assignment I agree to the following
#          “Aggies do not, lie, cheat, or steal, or tolerate those who do”
# “I have not given or received any unauthorized aid on this assignment”
#
#Name			Hunter Spier
#Section		501
#Assignment		Lab8_Act2
#Date			10/7/2020

s=[0.0001,0.2954,0.5705,0.8287,1.0723,1.3034,1.5236,1.7344,1.9374,2.1338,2.3251,2.5127,2.6983,2.8841].

t = float(input('Enter a temperature between 0 and 260 C: '))