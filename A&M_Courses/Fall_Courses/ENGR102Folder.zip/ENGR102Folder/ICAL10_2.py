#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 26 08:25:14 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: ICAL-10-2
# Date: 10/26/2020


## Part 1 ##
A = [[1.0,2.0],[3.0,4.0]]
print(A)


## Part 2 ##
v = [-1.0,3.0]
A = [[1.0,2.0],[3.0,4.0]]
B = [[3.0,-2.0],[2.0,1.0]]
C = [[1.0,1.5,-2.0],[2.0,1.0,-1.0],[3.0,-1.0,2.0]]
[[A[i][j]+B[i][j] for j in range(len(B[0]))] for i in range(len(A))] #the matrix A + B
print(sum(v[i] * v[i] for i in range(len(v)))) #the dot product v.v
print([sum(A[i][j] * v[j] for j in range(len(v))) for i in range(len(A))]) #the vector A * v
print([[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))])
