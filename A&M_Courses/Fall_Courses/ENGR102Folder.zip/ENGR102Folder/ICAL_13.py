#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov  9 08:37:16 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji, Hunter Spier, Liliana Salgado, Michael Camacho
# Course Header: Eng 102-451
# Assignment: ICAL 13
# Date: 11/9/2020

try:
    def C(x): #This line produced a unexpected indent as a run-time error 
        print(x)
    
    def B(y): #Would have affected this method
        y *= 2
        C(y)
        print(y)
    
    def A(z): #Would have affected this method
        z -= 1
        B(z)
        print(z)
    
    #Would affect the main function
    print('This is a nonsense program')
    A(1)
    A(2)
    A(3)
    print('All Done')

#Helped execute the run code and prevents the indentation error
except:
    def C(x):
        x += 1
        print(x)

    def B(y):
        y *= 2
        C(y)
        print(y)
    
    def A(z):
        z -= 1
        B(z)
        print(z)
    
    print('This is a nonsense program')
    A(1)
    A(2)
    A(3)
    print('All Done')
    