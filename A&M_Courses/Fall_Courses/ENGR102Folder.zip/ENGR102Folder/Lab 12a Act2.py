#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 19:56:36 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji, Hunter Spier, Liliana Salgado, Michael Camacho
# Course Header: Eng 102-451
# Assignment: Lab 12a Activity 2
# Date: 11/9/2020


def firstfunction(input_Number,start_Value,end_Value):
    
    y_Val
    
    









input_Number = input('Which polynomial would you like to test?\n1: x^3 + 1\n2: 3x^3 + 2x^2 - 6x + 5\n3: 2x^3 - x^2 + 3x - 2\nEnter the number: ')
start_value_Interval = input('\nEnter the lower value for the interval: ')
end_value_Interval = input('Enter the upper value for the interval: ')

if (input_Number == 1):
    
    
    