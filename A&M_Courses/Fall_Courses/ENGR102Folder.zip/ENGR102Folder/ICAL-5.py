#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 14 08:03:48 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: ICAL-5
# Date: 9/14/2020

#ICAL5-1
i = 1
while i < 6:
    print(i)
    i += 1


#ICAL5-2
num = 400
if num > 1:
    for i in range(2,num):
        if(num % i) == 0:
            print(num, 'is not a prime number')
            print(i,'times',num//i,'is',num)
            break
        else:
            print(num, 'is a prime number')
            
else:
    print(num,'is not a prime number')
    

#ICAL5-3
i = 1
while i < 6:
    print(i)
    if i == 3:
        break
    i += 1

#ICAL5-4
i = 0
while i < 6:
    i += 1
    if(i == 3):
        continue
    print(i)

#ICAL5-5
i = 1
while i < 6:
    print(i)
    i += 1
else:
    print('i is no longer less than 6')