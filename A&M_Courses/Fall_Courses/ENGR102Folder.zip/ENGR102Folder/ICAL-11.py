#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov  2 08:14:36 2020

@author: vishruth
"""
# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Name: Vishruth Balaji
# Course Header: Eng 102-451
# Assignment: Lab 11 ICAL
# Date: 11/2/2020

## Part A ##

#Define function passing the name and printing
def employee(name):
    print('Employee',name,'salary is:',7500)#Printing the employee name and salary

employee('Ben')#Call function
employee('Ben')#Call function


## Part B ##
#Define function ofeven numbers to a list
def even_numbers_List():
    evens_List = []#Creating empty list
    for i in range(4,31):#Ranging from 4 to 30
        if(i % 2 == 0):#Finding the even numbers
            evens_List.append(i)#Appending to the list
            
    return evens_List#Return the list

print(even_numbers_List())#Call and print the function